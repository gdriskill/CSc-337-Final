
class livingRoom extends tempClass {
    name = "livingRoom";
    crossword = {id: ["crossword"], played: false, occupies: [52,53]}
    objects = [this.crossword,this.exit];

    image = "../images/LivingRoom.png";
    move(location) {
        switch (location) {
            case("exit"): {
                travel("hallway");
            }
        }
    }
    look(item) {
        switch (item)
        {
            case(this.crossword.id[0]):
            {
                if(!this.objects[0].played) {
                    if(confirm("Play minigame?"))
                    {

                        this.objects[0].played = true;
                        this.updateGame();
                        this.playCrossGame();
                    }
                }
                else
                {
                    printData("The paper is already filled out.", thought);
                }
                break;
            }
            default:{
                printData("Its an old living room",thought);
                printData("Its an there a table here with something one it",thought);
            }
        }

    }
    interact(item) {
        switch (item){
            case(this.crossword.id[0]): {
                if (!this.objects[0].played) {
                    if (confirm("Play minigame?")) {
                        this.updateGame();
                        this.objects[0].played = true;
                        this.playCrossGame();
                    }
                } else {
                    printData("I'm tired, I don't want to play anymore.", thought);
                }
            }
            default:{
                printPickUpError();
            }
        }
    }

    updateGame()
    {
        var request = new XMLHttpRequest();
        if (!request) {
            alert("ERROR");
            return false;
        }
        request.onreadystatechange =async() => {
            if (request.readyState === XMLHttpRequest.DONE) {
                console.log("LOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOK");
                if(request.response !== "true"){
                    console.log(request.response);
                    //window.location = "";
                }
            }

        }

        let playGame = "crossword";
        let playHappy = "true";
        var url = "/play/game/";
        request.open('POST', url, true);
        request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        request.send('playGame='+playGame+"&playHappy="+playHappy);
    }

    playCrossGame() {

        var urlAll = "/crossword";
        var requestAll = new XMLHttpRequest();
        if (!requestAll) {
            alert("ERROR");
            return false;
        }
        requestAll.onreadystatechange = () => {
            if (requestAll.readyState === XMLHttpRequest.DONE) {
                if (requestAll.status === 200) {
                    saveGameData().then(() => {
                        window.location.href = "crossword";
                    });
                } else {
                    alert("ERROR lol "+requestAll.status);
                }

            }
        }
        requestAll.open('GET', urlAll, true);
        requestAll.send();


    }


/*
        var request = new XMLHttpRequest();
        if (!request) {
            alert("ERROR");
            return false;
        }
        request.onreadystatechange =async() => {
            if (request.readyState === XMLHttpRequest.DONE) {

                console.log("LOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOK");
                console.log(request.response);
                if(request.response !== "true"){
                    console.log(request.response);
                    //window.location = "";
                }
            }

        }

        let info = "crosswordFolder";
        var url = "/crosswordFolder";
        request.open('POST', url, true);
        request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        request.send('info='+info);
    }

 */
}

