class bathroom extends tempClass {
    name = "bathroom";
    mirror = {id: ["mirror"], played: false, occupies: [21,22,29,30,37,38]}
    objects = [this.mirror,this.exit];

    image = "../images/Bathroom.png";
    move(location) {
        switch (location) {
            case("exit"): {
                travel("hallway");
            }
        }
    }
    look(item) {
        switch(item){
            case(this.mirror.id[0]):{
                if(!this.objects[0].played) {
                    if(confirm("Play minigame?"))
                    {
                        this.updateGame();
                        this.objects[0].played = true;
                        this.playMirrorGame();
                    }
                }
                else
                {
                    printData("A game of tiktaktoe was played on the mirror", thought);
                }
                break;
            }
            default:{
                printData("Looks like an old bathroom",thought);
                if(this.objects[0].played)
                {
                    printData("A game of tiktaktoe was played on the mirror", thought);
                }
                else {
                    printData("Something is odd with that mirror", thought);
                }
                break;
            }
        }
    }

    interact(item) {
        switch (item)
        {
            case(this.mirror.id[0]):{
                if(!this.objects[0].played)
                {
                    if(confirm("Play minigame?"))
                    {
                        this.updateGame();
                        this.objects[0].played = true;
                        this.playMirrorGame();
                    }
                }
                else
                {
                    printData("Look like the ghost doesn't want to play anymore", thought);
                }
            }
        }
    }
    updateGame()
    {
        var request = new XMLHttpRequest();
        if (!request) {
            alert("ERROR");
            return false;
        }
        request.onreadystatechange =async() => {
            if (request.readyState === XMLHttpRequest.DONE) {
                console.log("LOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOK");
                if(request.response !== "true"){
                    console.log(request.response);
                    //window.location = "";
                }
            }

        }

        let playGame = "tiktaktoe";
        let playHappy = "true";
        var url = "/play/game/";
        request.open('POST', url, true);
        request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        request.send('playGame='+playGame+"&playHappy="+playHappy);
    }
    playMirrorGame(){
        var urlAll = "/tiktaktoe";
        var requestAll = new XMLHttpRequest();
        if (!requestAll) {
            alert("ERROR");
            return false;
        }
        requestAll.onreadystatechange = () => {
            if (requestAll.readyState === XMLHttpRequest.DONE) {
                if (requestAll.status === 200) {
                    saveGameData().then(()=>{window.location.href ="tiktaktoe";});
                } else {
                    alert("ERROR");
                }
            }
        }
        requestAll.open('GET', urlAll, true);
        requestAll.send();
    }
}
