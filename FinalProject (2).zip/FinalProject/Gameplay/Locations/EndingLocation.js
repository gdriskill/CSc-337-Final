
class ending extends tempClass {
    name = "ending";
    variable = {id: ["variable"], played: false, occupies: []}
    objects = [this.variable];

    image = "../images/ending.png";
    look(item) {
        switch (item)
        {
            default:{
                document.getElementById("Stats").hidden = "";
                if(!this.objects[0].played) {
                    printData("As you walk down the hallway your mind begins to crumble", thought);
                    printData("You can make out the outline of someone", thought);
                    printData("They seem to be approaching the house", thought);
                    printData("What do you tell them?", thought);
                    document.getElementById("inputOutline").style.display = "block";
                    this.objects[0].played = true;
                }
                else
                {
                    printData("Nothing but the void is left.", thought);
                }

            }
        }
    }


    /*
            var request = new XMLHttpRequest();
            if (!request) {
                alert("ERROR");
                return false;
            }
            request.onreadystatechange =async() => {
                if (request.readyState === XMLHttpRequest.DONE) {

                    console.log("LOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOK");
                    console.log(request.response);
                    if(request.response !== "true"){
                        console.log(request.response);
                        //window.location = "";
                    }
                }

            }

            let info = "crosswordFolder";
            var url = "/crosswordFolder";
            request.open('POST', url, true);
            request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            request.send('info='+info);
        }

     */
}


