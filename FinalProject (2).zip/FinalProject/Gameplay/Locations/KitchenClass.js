class kitchen extends tempClass {
    name = "kitchen";
    plate = {id: ["plate"], played: false, breadPlaced: false, occupies: [47]}
    objects = [this.plate,this.exit];

    image = "../images/Kitchen.png";
    move(location) {
        switch (location) {
            case("exit"): {
                travel("hallway");
                break;
            }
            case(this.plate.id[0]):
            {
                if (this.objects[0].breadPlaced) {
                    printData("You did the right thing :>", action);
                    break;
                }
            }
            default:{
                printMoveError();
            }

        }
    }
    interact(item) {
        switch (item){
            case(this.plate.id[0]):{
                if (this.objects[0].breadPlaced) {
                    printData("You did the right thing :>", action);
                }
                else {
                    if (!this.objects[0].played) {
                        if (confirm("There are bugs on the plate! You have to crush them!!\nPlay minigame?")) {
                            this.objects[0].played = true;
                            this.updateGame();
                            this.playSpiderGame();
                        }
                    } else {
                        printData("I already killed all the bugs", thought);
                    }
                }
                break;
            }
            default:{
                printPickUpError();
                break;
            }
        }
    }
    itemInteract(playerItem, item) {
        switch(item){
            case(this.plate.id[0]):{
                if(this.objects[0].played) {
                    if (this.objects[0].breadPlaced) {
                        printData("You did the right thing :>", action);
                    } else {
                        if (playerItem === "Bread") {
                            var request = new XMLHttpRequest();
                            if (!request) {
                                alert("ERROR");
                                return false;
                            }
                            request.onreadystatechange = async () => {
                            }
                            var url = "/place/bread";
                            request.open('POST', url, true);
                            request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                            request.send('score=1');
                            document.body.style.backgroundColor = "#fdb448";
                            printData("You place the bread on the plate", action);
                            printData("The bread then starts to glow a bright orange and suddenly disappears", action);
                            printData("You feel at peace with yourself", action);
                            printData("Good job :>.", thought);
                            inventory.useItem("Bread");
                            this.objects[0].breadPlaced = true;
                        } else {
                            printData("It feels like something else should go here", thought);
                        }
                    }
                }
                else
                {
                    printData("The plate is covered in spiders",thought);
                    printData("I have to at least kill a few of them before putting something on it",thought);
                }
                break;
            }
            default:{
                printData("I'm not using this on that",error);
            }
        }
    }

    look(item) {
        switch (item){
            case(this.plate.id[0]):{
                if (this.objects[0].breadPlaced) {
                    printData("You did the right thing :>", action);
                }
                else {
                    if (!this.objects[0].played) {
                        if (confirm("There are bugs on the plate! You have to crush them!!\nPlay minigame?")) {
                            this.objects[0].played = true;
                            this.updateGame();
                            this.playSpiderGame();
                        }
                    } else {
                        printData("It feels like something goes here", thought);
                    }
                }
                break;
            }
            default:{
                printData("This kitchen is falling apart",thought);
                printData("You spot a plate on the counter",action);
                if(this.objects[0].played)
                {
                    printData("It feels like something goes here",thought);
                }
                break;
            }
        }
    }

    updateGame()
    {
        var request = new XMLHttpRequest();
        if (!request) {
            alert("ERROR");
            return false;
        }
        request.onreadystatechange =async() => {
            if (request.readyState === XMLHttpRequest.DONE) {
                if(request.response !== "true"){
                    console.log(request.response);
                    //window.location = "";
                }
            }

        }

        let playGame = "spider";
        let playHappy = "true";
        var url = "/play/game/";
        request.open('POST', url, true);
        request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        request.send('playGame='+playGame+"&playHappy="+playHappy);
    }

    playSpiderGame() {
        var urlAll = "/spider";
        var requestAll = new XMLHttpRequest();
        if (!requestAll) {
            alert("ERROR");
            return false;
        }
        requestAll.onreadystatechange = () => {
            if (requestAll.readyState === XMLHttpRequest.DONE) {
                if (requestAll.status === 200) {
                    saveGameData().then(() => {
                        window.location.href = "spider";
                    });
                } else {
                    alert("ERROR: "+requestAll.status);
                }

            }
        }
        requestAll.open('GET', urlAll, true);
        requestAll.send();


    }


}


