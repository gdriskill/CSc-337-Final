/**
 * File name: AlchemyTableClass.js
 * Assignment: Final Project CSC 337
 * Purpose: Creates the class for the alchemy table location. This is where the player
 *      can solve the alchemy puzzle. Contains all the objects located in the room, 
 *      and what happens when the user moves, interacts or looks at these objects.
 */
class alchemyTableClass extends tempClass {
    name = "alchemyTable";

    // all the objects in this room
    cauldron = {id: ["cauldron"], occupies: [35,36,37,38,43,44,45,46,51,52,53,54]};
    bluePotion = inventory.getItemData("Blue Potion");
    redPotion = inventory.getItemData("Red Potion");
    greenPotion = inventory.getItemData("Green Potion");
    objects = [this.bluePotion,this.redPotion,this.greenPotion,this.cauldron,this.exit];

    //background image
    image = "../images/AlchemyTable.png";

    /**
     * Updates this room when the game loads, so all the conditions of the room are correct
     * even after a player leaves the room and returns later.
     */
    updateLocation() {
        this.cauldron = {id: ["cauldron"], occupies: [35,36,37,38,43,44,45,46,51,52,53,54]};
        this.bluePotion = inventory.getItemData("Blue Potion");
        this.redPotion = inventory.getItemData("Red Potion");
        this.greenPotion = inventory.getItemData("Green Potion");
        this.objects = [this.bluePotion,this.redPotion,this.greenPotion,this.cauldron,this.exit];
    }

     /**
     * Handles cases for when a player moves to a specified location in the 
     * room. 
     * @param {*} location  The location player has clicked on 
     */
    move(location) {
        switch (location) {
            case("exit"): {
                travel("alchemyRoom");
                break;
            }
            default:{
                printMoveError();
            }
        }
    }

    /**
     * Handles cases for when a player interacts with a specified item in the 
     * room.
     * @param {*} item      the item from the room the player is trying to 
     *                      interact with
     */
    interact(item) {
        switch(item){
            case(this.bluePotion.id[0]):{
                inventory.pickUp(this.bluePotion.id[0]);
                break;
            }
            case(this.redPotion.id[0]):{
                inventory.pickUp(this.redPotion.id[0]);
                break;
            }
            case(this.greenPotion.id[0]):{
                inventory.pickUp(this.greenPotion.id[0]);
                break;
            }
            default:{
                printPickUpError();
            }
        }
    }

    /**
     * Handles cases for when a player tries to look at a specified item
     * in the room
     * @param {*} item      The item the player has clicked on
     */
    look(item) {
        switch (item){
            case(this.cauldron.id[0]):{
                printData("Looks like an old cauldron",thought);
                break;
            }
            default:{
                printData("Looks like an old alchemy table",thought);
                break;
            }
        }
    }

    /**
     * Handles cases for when a player tries to interact on an object with something
     * from their inventory.
     * @param {*} playerItem    the item the player is using from their inventory
     * @param {*} item      the item in the room the player in interacting on
     */
    itemInteract(playerItem, item) {
        switch(item)
        {
            case(this.cauldron.id[0]):{
                currentMix.push(playerItem);
                printData(playerItem+" Added",action);
            if(currentMix.length === 5)
            {
                if(currentMix.toString() === "Red Potion,Red Potion,Blue Potion,Green Potion,Blue Potion")
                {
                    printData("You did it",thought)
                    inventory.useItem("Red Potion");
                    inventory.useItem("Blue Potion");
                    inventory.useItem("Green Potion");
                    inventory.pickUp("Cure Potion");

                }
                else
                {
                    printData("That didn't seem right",thought)
                    printData("I should double check the book",thought)
                    currentMix = [];
                }
            }
            break;
            }
        }
    }
}