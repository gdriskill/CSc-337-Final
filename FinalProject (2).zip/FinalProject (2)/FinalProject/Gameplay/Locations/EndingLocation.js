/**
 * File name: EndingLocation.js
 * Assignment: Final Project CSC 337
 * Purpose: Creates the class for the end of the game. Player gets to write a message
 *      to send to future players entering the house.
 */
class ending extends tempClass {
    name = "ending";
    variable = {id: ["variable"], played: false, occupies: []}
    objects = [this.variable];

    image = "../images/ending.png";

    /**
     * Handles cases for when a player tries to look at a specified item
     * in the room. There is only one case, as this is the ending screen. 
     * Opens up a text box where players can type a message for a future
     * player.
     * @param {*} item      The item the player has clicked on
     */
    look(item) {
        switch (item)
        {
            default:{
                document.getElementById("Stats").hidden = "";
                if(!this.objects[0].played) {
                    printData("As you walk down the hallway your mind begins to crumble", thought);
                    printData("You can make out the outline of someone", thought);
                    printData("They seem to be approaching the house", thought);
                    printData("What do you tell them?", thought);
                    document.getElementById("inputOutline").style.display = "block";
                    this.objects[0].played = true;
                }
                else
                {
                    printData("Nothing but the void is left.", thought);
                }

            }
        }
    }


    /*
            var request = new XMLHttpRequest();
            if (!request) {
                alert("ERROR");
                return false;
            }
            request.onreadystatechange =async() => {
                if (request.readyState === XMLHttpRequest.DONE) {

                    console.log("LOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOK");
                    console.log(request.response);
                    if(request.response !== "true"){
                        console.log(request.response);
                        //window.location = "";
                    }
                }

            }

            let info = "crosswordFolder";
            var url = "/crosswordFolder";
            request.open('POST', url, true);
            request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            request.send('info='+info);
        }

     */
}


