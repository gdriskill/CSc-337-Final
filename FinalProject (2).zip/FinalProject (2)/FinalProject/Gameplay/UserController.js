/**
 * File name: UserController.js
 * Assignment: Final Project CSC 337
 * Purpose: The UserController class handles user's input and 
 *      faciliates the interaction with the game.
 */
const look = ["look","see","stare","view"];
const grab = ["grab","take","pick up","acquire","open"];
const move = ["move","go to","leave","enter"];
const listOfCommands = [look,grab,move];

class userController
{
    /**
     * Checks if the user input is one of the default commands
     * @param userInput 
     * @returns boolean
     */
    defaultCommand(userInput)
    {
        for(let i = 0; i < listOfCommands.length; i++)
        {
            for(let j = 0; j < listOfCommands[i].length; j++)
            {
                if(userInput.toLowerCase() === listOfCommands[i][j])
                {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 
     * Gets object at the specified location
     * @param objects array of objects
     * @param imageLocation the location to get object at 
     * @returns object at the specified location
     */
    lookLocation(objects, imageLocation)
    {
        for(let i = 0; i < objects.length; i++)
        {
            for(let j = 0; j < objects[i].occupies.length; j++)
            {
                if(imageLocation ===(objects[i].occupies[j]) && (!objects[i].pickedUp))
                {
                    return(objects[i].id[0]);
                }
            }
        }
        return "default";
    }

    /**
     * Figures out which of the three types (look, interact, move) the user's
     * input is
     */
    getInputType(userInput)
    {
        for(let i = 0; i < listOfCommands.length; i++)
        {
            for(let j = 0; j < listOfCommands[i].length; j++)
            {

                if(userInput.toLowerCase().includes(listOfCommands[i][j]))
                {
                    return(listOfCommands[i][0]);
                }
            }
        }
        return "not cool";
    }
    getItemType(objects,userInput)
    {
        for(let i = 0; i < objects.length; i++)
        {
            for(let j = 0; j < objects[i].id.length; j++)
            {
                if(userInput.toLowerCase().includes(objects[i].id[j]))
                {
                    console.log(objects[i].id[0]);
                    return(objects[i].id[0]);
                }
            }
        }
        if(this.defaultCommand(userInput))
        {
            return "default";
        }

        return "";
    }


}