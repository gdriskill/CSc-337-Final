class epicThingOkay{
    name
    constructor(username) {
        name = username;
    }
    getName(){
        return name;
    }
    printThing(testWord){
        return testWord;
    }

}