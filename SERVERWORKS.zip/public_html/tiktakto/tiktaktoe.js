


let possiblespots = ['sq11','sq12','sq13','sq21','sq22', 'sq23', 'sq31', 'sq32', 'sq33']
gameboard = [['B','B','B'],['B','B','B'],['B','B','B']]


function addtac(location){
    console.log('in addtac')
    let currentdata = document.getElementById(location).value;
    console.log('currentdata: ' + currentdata)
    let row = parseInt(location[2]);
    let col = parseInt(location[3]);
    console.log('row and col are:' + row +col)
    if(currentdata == 'X' || currentdata == 'O'){
        alert('Choose an empty Cell')
    }else{

        element = document.getElementById(location)
        element.outerHTML = '<img src=\'myX.png\' alt=\'myX\' class=\'x\'>'
        gameboard[row-1][col-1] = 'X'
        console.log('gameboard is:' + gameboard)
        wonval = didiwin(gameboard, 'X')
        console.log('wonval is: ' + wonval)
        if(wonval == 'true'){
            document.getElementById('messagedisplay').innerHTML = 'You won!'

        }else{
                    
            let i =0
            while(i < possiblespots.length){ 
                if ( possiblespots[i] === location) { 
                    possiblespots.splice(i, 1); 
                }
                i = i + 1
            }
            console.log(possiblespots)

        document.getElementById('messagedisplay').innerHTML = 'Wait while other player chooses a spot'
        
        compspot = defense();
        console.log('compspot from defense:' + compspot)
        if(compspot == 'nothing'){

            compspoti = getRandomIntInclusive(0,possiblespots.length -1);
            compspot = possiblespots[compspoti];
            let row = parseInt(compspot[2]);
            let col = parseInt(compspot[3]);
            gameboardspot = gameboard[row-1][col-1]
            while(((gameboardspot == 'O') || (gameboardspot == 'X'))){
                compspoti = getRandomIntInclusive(0,possiblespots.length -1);
                compspot = possiblespots[compspoti];
                let row = parseInt(compspot[2]);
                let col = parseInt(compspot[3]);
                gameboardspot = gameboard[row-1][col-1]
                console.log('gameboardspot is: ' + gameboardspot)
            }
            console.log(compspot);
        };


        setTimeout(() => {
            console.log('after timeout')
            console.log('compspot:' + compspot)

            element = document.getElementById(compspot)
            console.log('element:' + element)
            element.outerHTML = '<img src=\'bloodyO.png\' alt=\'compo\' class=\'x\'>'
            let row = parseInt(compspot[2]);
            let col = parseInt(compspot[3]);
            gameboard[row-1][col-1] = 'O'
            wonval = didiwin(gameboard, 'O')
            console.log('wonval is: ' + wonval)
            if(wonval == 'true'){
                document.getElementById('messagedisplay').innerHTML = 'Computer!'

            }else{
                for( var i = 0; i < possiblespots.length; i++){ 
                    if ( possiblespots[i] === compspot) { 
                        possiblespots.splice(i, 1); 
                    }
                }

                document.getElementById('messagedisplay').innerHTML = 'Your turn'}

          }, 2000);
        }
    }
};

function getRandomIntInclusive(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1) + min); //The maximum is inclusive and the minimum is inclusive
}


function didiwin(gameboard, mytac){
    //check horiz
    r = 0
    c = 0
    col1cou = 0
    col2cou = 0
    col3cou = 0
    while(r<3){
        console.log('mytac is :' + mytac)
        console.log('gameboard[r] is: ' + gameboard[r])
        console.log('mytac x3 array: ' + [mytac,mytac,mytac])
        if(gameboard[r][0] == mytac && gameboard[r][1] == mytac && gameboard[r][2] == mytac){
            console.log('won horizontally')
            return('true')
        }
        r = r+1
    }

    r = 0
    c = 0 
    //check vert
    while(r<3){
        if(gameboard[r][0] == mytac){
            col1cou = col1cou +1
            }
        if(gameboard[r][1] == mytac){
            col2cou = col2cou +1
            }
        if(gameboard[r][2] == mytac){
            col3cou = col3cou +1
            }
        r = r+1
    }
    console.log('colcount 1,2,3 is: ' + col1cou + col2cou + col3cou )
    if(col1cou == 3 || col2cou == 3 || col3cou == 3){
        console.log('won vertically')
        return('true')
    }

        //check diag
    if(gameboard[0][0] == mytac && gameboard[1][1] == mytac && gameboard[2][2] == mytac){
        return('true')
    }
    if(gameboard[0][2] == mytac && gameboard[1][1] == mytac && gameboard[2][0] == mytac){
        return('true')
    }
    }


function defense(){
    console.log('defense function')
    // check horiz
    r = 0
    while(r <3){
        row = gameboard[r]
        if (row[0] == 'X' && row[1] == 'X'){
            rownum = r +1 
            myspot= 'sq' +  rownum + '3'
            if(!(row[2] == 'O' || row[2] == 'X')){
                return myspot
            }
        }
        if (row[1] == 'X' && row[2] == 'X'){
            rownum = r +1 
            myspot= 'sq' +  rownum + '1'
            if(!(row[0] == 'O' || row[0] == 'X')){
                return myspot
            }        
        }
        if (row[0] == 'X' && row[2] == 'X'){
            rownum = r +1 
            myspot= 'sq' +  rownum + '2'
            if(!(row[1] == 'O' || row[1] == 'X')){
                return myspot
            }        
        }
        r = r+1

    
    };

// check diag + vert
if (gameboard[0][0] == 'X'){
    if(gameboard[2][2] == 'X'){
        myspot= 'sq22'
        if(!(gameboard[1][1] == 'O' || gameboard[1][1] ==  'X')){
            return myspot
        }
    };
    if(gameboard[2][0] == 'X'){
        myspot= 'sq21'
        if(!(gameboard[1][0] == 'O' || gameboard[1][0] ==  'X')){
            return myspot
        }    };
    if(gameboard[1][1] == 'X'){
        myspot= 'sq33'
        if(!(gameboard[2][2] == 'O' || gameboard[2][2] ==  'X')){
            return myspot
        }    };
    if(gameboard[1][0] == 'X'){
        myspot= 'sq31'
        if(!(gameboard[2][0] == 'O' || gameboard[2][0] ==  'X')){
            return myspot
        }    };
};

if (gameboard[0][1] == 'X'){
    if(gameboard[1][1] == 'X'){
        myspot= 'sq32'
        if(!(gameboard[2][1] == 'O' || gameboard[2][1] ==  'X')){
            return myspot
        }    };
    if(gameboard[2][1] == 'X'){
        myspot= 'sq22'
        if(!(gameboard[1][1] == 'O' || gameboard[1][1] ==  'X')){
            return myspot
        }    };
};

if (gameboard[0][2] == 'X'){
    if(gameboard[2][2] == 'X'){
        myspot= 'sq23'
        if(!(gameboard[1][2] == 'O' || gameboard[1][2] ==  'X')){
            return myspot
        }    };
    if(gameboard[1][2] == 'X'){
        myspot= 'sq33'
        if(!(gameboard[2][2] == 'O' || gameboard[2][2] ==  'X')){
            return myspot
        }    };
    if(gameboard[2][0] == 'X'){
        myspot= 'sq22'
        if(!(gameboard[1][1] == 'O' || gameboard[1][1] ==  'X')){
            return myspot
        }     };
    if(gameboard[1][1] == 'X'){
        myspot= 'sq31'
        if(!(gameboard[2][0] == 'O' || gameboard[2][0] ==  'X')){
            return myspot
        }     };
};


// row 2

if (gameboard[2][0] == 'X'){
    if(gameboard[1][0] == 'X'){
        myspot= 'sq11'
        if(!(gameboard[0][0] == 'O' || gameboard[0][0] ==  'X')){
            return myspot
        }     };
        if(gameboard[0][0] == 'X'){
            myspot= 'sq21'
            if(!(gameboard[1][0] == 'O' || gameboard[1][0] ==  'X')){
                return myspot
            }     };
    if(gameboard[1][1] == 'X'){
        myspot= 'sq13'
        if(!(gameboard[0][2] == 'O' || gameboard[0][2] ==  'X')){
            return myspot
        }     };
    if(gameboard[0][2] == 'X'){
        myspot= 'sq22'
        if(!(gameboard[1][1] == 'O' || gameboard[1][1] ==  'X')){
            return myspot
        }     };

};

return 'nothing'


};