


let possiblespots = ['sq11','sq12','sq13','sq21','sq22', 'sq23', 'sq31', 'sq32', 'sq33']
let gameboard = [['B','B','B'],['B','B','B'],['B','B','B']]


function addtac(location){
    console.log('in addtac')
    let currentdata = document.getElementById(location).value;
    console.log('currentdata: ' + currentdata)
    let row = parseInt(location[2]);
    let col = parseInt(location[3]);
    console.log('row and col are:' + row +col)
    if(currentdata == 'X' || currentdata == 'O'){
        alert('Choose an empty Cell')
    }else{
        document.getElementById(location).value = 'X'
        gameboard[row-1][col-1] = 'X'
        console.log('gameboard is:' + gameboard)
        wonval = didiwin(gameboard, 'X')
        console.log('wonval is: ' + wonval)
        if(wonval == 'true'){
            document.getElementById('messagedisplay').innerHTML = 'You won!'

        }else{
                    
            let i =0
            while(i < possiblespots.length){ 
                if ( possiblespots[i] === location) { 
                    possiblespots.splice(i, 1); 
                }
                i = i + 1
            }
            console.log(possiblespots)

        document.getElementById('messagedisplay').innerHTML = 'Wait while other player chooses a spot'

        compspoti = getRandomIntInclusive(0,possiblespots.length -1)
        compspot = possiblespots[compspoti]
        console.log(compspot)

        setTimeout(() => {
            console.log('after timeout')
            document.getElementById(compspot).value = 'O';
            let row = parseInt(compspot[2]);
            let col = parseInt(compspot[3]);
            gameboard[row-1][col-1] = 'O'
            wonval = didiwin(gameboard, 'O')
            console.log('wonval is: ' + wonval)
            if(wonval == 'true'){
                document.getElementById('messagedisplay').innerHTML = 'Computer!'

            }else{
                for( var i = 0; i < possiblespots.length; i++){ 
                    if ( possiblespots[i] === compspot) { 
                        possiblespots.splice(i, 1); 
                    }
                }

                document.getElementById('messagedisplay').innerHTML = 'Your turn'}

          }, 2000);
        }
    }
};

function getRandomIntInclusive(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1) + min); //The maximum is inclusive and the minimum is inclusive
}


function didiwin(gameboard, mytac){
    //check horiz
    r = 0
    c = 0
    col1cou = 0
    col2cou = 0
    col3cou = 0
    while(r<3){
        console.log('mytac is :' + mytac)
        console.log('gameboard[r] is: ' + gameboard[r])
        console.log('mytac x3 array: ' + [mytac,mytac,mytac])
        if(gameboard[r][0] == mytac && gameboard[r][1] == mytac && gameboard[r][2] == mytac){
            console.log('won horizontally')
            return('true')
        }
        r = r+1
    }

    r = 0
    c = 0 
    //check vert
    while(r<3){
        if(gameboard[r][0] == mytac){
            col1cou = col1cou +1
            }
        if(gameboard[r][1] == mytac){
            col2cou = col2cou +1
            }
        if(gameboard[r][2] == mytac){
            col3cou = col3cou +1
            }
        r = r+1
    }
    console.log('colcount 1,2,3 is: ' + col1cou + col2cou + col3cou )
    if(col1cou == 3 || col2cou == 3 || col3cou == 3){
        console.log('won vertically')
        return('true')
    }

        //check diag
    if(gameboard[0][0] == mytac && gameboard[1][1] == mytac && gameboard[2][2] == mytac){
        return('true')
    }
    if(gameboard[0][2] == mytac && gameboard[1][1] == mytac && gameboard[2][0] == mytac){
        return('true')
    }
    }
