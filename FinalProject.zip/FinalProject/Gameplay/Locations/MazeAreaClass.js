/**
 * File name: MazeAreaClass.js
 * Assignment: Final Project CSC 337
 * Purpose: Creates the class for the maze location. Here the player can play
 *      the maze puzzle. Contains all the objects located in the room, 
 *      and what happens when the user moves, interacts or looks at these objects.
 */
class mazeArea extends tempClass {
    name = "mazeArea";
    // all the objects in this room
    leftDoor = {id: ["left door"], occupies: [18,19,26,27,34,35,42,43,50]}
    rightDoor = {id: ["right door"], occupies: [23,31,39,47,55,24,32,40,48,56]}
    forwardDoor = {id: ["forward door"], occupies: [28,29,36,37,44,45]}
    objects = [this.leftDoor,this.rightDoor,this.forwardDoor, this.exit];

    image = "../images/MazeArea.png";

    /**
     * Handles cases for when a player tries to look at a specified location
     * in the room
     * @param {*} location     The location the player has clicked on
     */
    look(location)
    {
        switch(location) {
            case(this.leftDoor.id[0]):
            {
                printData("You look to your left and see a long dark hallway",action);
                break;
            }
            case(this.forwardDoor.id[0]):
            {
                printData("You look in-front of you and see a long dark hallway",action);
                break;
            }
            case(this.rightDoor.id[0]):
            {
                printData("You look to your right and see a long dark hallway",action);
                break;
            }
            default:{
                if(currentPath === 0){
                    printData("Looks like an old maze system, I could easy get lost here.",thought);
                }
                else{
                    printData("This maze looks the same everywhere",thought);
                    printData("I need to pay attention if I don't want to get lost",thought);
                }
                break;
            }
        }
    };

    /**
     * Handles cases for when a player moves to a specified location in the 
     * room. 
     * @param {*} location  The location player has clicked on 
     */
    move(location) {
        switch (location) {
            case("exit"): {
             if(currentPath === 0)
             {
                 travel("mazeRoom");
             }
             else
             {

                     if (confirm("I think I know how to get back to the main room but I would have to start over again when I come back.\nExit Maze?")) {
                         travel("mazeRoom");
                     }
             }
                break;
            }
            case("default"):
            {
                printMoveError();
                break;
            }
            default:{
                printData("You walk through the "+location,action);
                switch(currentPath)
                {
                    //First
                    case(0):
                    {;
                        if(location === this.leftDoor.id[0])
                        {
                            document.body.style.backgroundColor = "#110417";
                            printData("Feels like you're going the right way",thought);
                            currentPath++;
                        }
                        else
                        {
                            this.wrongDoor();
                        }
                        break;
                    }
                    //Left

                    case(1):
                    {
                        if(location === this.rightDoor.id[0])
                        {
                            document.body.style.backgroundColor = "#170404";
                            printData("Feels like you're going the right way",thought);
                            currentPath++;
                        }
                        else
                        {
                            this.wrongDoor();
                        }
                        break;
                    }
                    //Right

                    case(2):
                    {
                        if(location === this.forwardDoor.id[0])
                        {
                            document.body.style.backgroundColor = "#050c02";
                            printData("Feels like you're going the right way",thought);
                            currentPath++;
                        }
                        else
                        {
                            this.wrongDoor();
                        }
                        break;
                    }
                    //Forward

                    case(3):
                    {
                        if(location === this.leftDoor.id[0])
                        {
                            document.body.style.backgroundColor = "#0c0b02";
                            printData("Feels like you're going the right way",thought);
                            currentPath++;
                        }
                        else
                        {
                            this.wrongDoor();
                        }
                        break;
                    }
                    //Left

                    case(4):
                    {
                        if(location === this.leftDoor.id[0])
                        {
                            document.body.style.backgroundColor = "#0c020c";
                            printData("Feels like you're going the right way",thought);
                            currentPath++;
                        }
                        else
                        {
                            this.wrongDoor();
                        }
                        break;
                    }
                    //Left

                    case(5):
                    {
                        if(location === this.forwardDoor.id[0])
                        {
                            printData("YOU DID IT",action)
                            travel("outside").then(()=>newGameLoad());
                        }
                        else
                        {
                            this.wrongDoor();
                        }
                        break;
                    }
                }
                break;
                printMoveError();
            }
        }
    }

    /**
     * When the player goes the wrong was in the maze
     */
    wrongDoor(){
        currentPath = 0;
        document.body.style.backgroundColor = "#03090c";
        printData("Wait, I'm at the start again",thought);
        printData("I think that was the wrong door",thought);
        printData("I should make sure to read this book if I don't want to get lost",thought);

    }
}