class bookRoom extends tempClass{
    name = "bookRoom";
    atlas = inventory.getItemData("Atlas Book");
    alchemy = inventory.getItemData("Alchemy Book");
    cryptography = inventory.getItemData("Cryptography Book");
    bookDoor = {id: ["bookDoor"], locked: true, occupies: [18,19,26,27,34,35,42,43]}
    objects = [this.atlas,this.alchemy,this.cryptography,this.bookDoor,this.exit];

    image = "../images/BookRoom.png";

    updateLocation() {
        this.atlas = inventory.getItemData("Atlas Book");
        this.alchemy = inventory.getItemData("Alchemy Book");
        this.cryptography = inventory.getItemData("Cryptography Book");
        this.bookDoor = {id: ["bookDoor"], locked: true, occupies: [18,19,26,27,34,35,42,43]}
        this.objects = [this.atlas,this.alchemy,this.cryptography,this.bookDoor,this.exit];
    }

    look(item)
    {
        switch (item){
            case(this.atlas.id[0]):
            {
                printData("It's a book that says atlas",thought);
                break;
            }
            case(this.alchemy.id[0]):
            {
                printData("It's a book that says alchemy",thought);
                break;
            }

            case(this.cryptography.id[0]):
            {
                printData("It's a book that says cryptography",thought);
                break;
            }
            case(this.bookDoor.id[0]):
            {
                printData("Its a big metal door", thought);
                if(!this.objects[3].locked) {
                    printData("Seems like the door is locked but you dont see a way to unlock it", thought);
                }
                else
                {
                    printData("Seems to be unlocked now", thought);
                }
                break;
            }
            default:
            case("default"):{
                printData("The room feels cold and distance",thought);
                if(playerBook === undefined) {
                    printData("You see 3 book on the table", thought);
                    printData("They all seem to be different", thought);
                }
                else
                {
                    printData("The rest of the books are gone", thought);
                }
                break;
            }
        }
    }

    move(location)
    {
        switch(location){
            case(this.bookDoor.id[0]):
            {
                if(!this.objects[3].locked)
                {
                    printData("You turn the door handle but it doesn't move", action);
                    printData("Seems like the door is locked but you dont see a way to unlock it", thought);
                }
                else
                {
                travel("hallway");
                }
                break;
            }
            case("exit"):
            {
                printData("You turn around and try to open the door", action);
                printData("You try turning the handle but it wont move", action);
                printData("The door's locked", thought);
                break;
            }
            default:{
                printMoveError();
            }
        }
    }
    interact(item) {
        let gotBook = false;
        switch (item)
        {
            case(this.cryptography.id[0]):
            {
                if(this.objects[3].locked === true) {
                    gotBook = true;
                    printData("As you pick up the book that says cryptography you feel the room shake",action);
                    printData("Suddenly the rest of the books disappear and you hear a click by the back door",action);
                    printData("\"CLICK\"",saying);
                    playerBook = this.cryptography.id[0];
                    inventory.pickUp(this.cryptography.id[0]);

                    inventory.removeImage(inventory.getItemData(this.atlas.id[0]));
                    inventory.getItemData(this.atlas.id[0]).pickedUp = true;

                    inventory.removeImage(inventory.getItemData(this.alchemy.id[0]));
                    inventory.getItemData(this.alchemy.id[0]).pickedUp = true;

                    console.log(inventory.getItemData(this.atlas.id[0]));
                    console.log(inventory.getItemData(this.cryptography.id[0]));
                    this.objects[3].locked = false;


                    let random = Math.floor(Math.random() * 2);
                    //printData(random,saying);
                    switch (random) {
                        case(0): {
                            puzzleRoom = "mazeRoom";
                            break;
                        }
                        case(1): {
                            puzzleRoom = "alchemyRoom";
                            break;
                        }
                    }
                    puzzleRoom = "codeRoom";
                }
                break;
            }
            case(this.alchemy.id[0]):
            {
                if(this.objects[3].locked === true) {
                    gotBook = true;
                    printData("As you pick up the book that says alchemy you feel the room shake",action);
                    printData("Suddenly the rest of the books disappear and you hear a click by the back door",action);
                    printData("\"CLICK\"",saying);
                    playerBook = this.alchemy.id[0];
                    inventory.pickUp(this.alchemy.id[0]);

                    inventory.removeImage(inventory.getItemData(this.atlas.id[0]));
                    inventory.getItemData(this.atlas.id[0]).pickedUp = true;

                    inventory.removeImage(inventory.getItemData(this.cryptography.id[0]));
                    inventory.getItemData(this.cryptography.id[0]).pickedUp = true;
                    this.objects[3].locked = false;

                    let random = Math.floor(Math.random() * 2);
                    //printData(random,saying);
                    switch (random) {
                        case(0): {
                            puzzleRoom = "mazeRoom";
                            break;
                        }
                        case(1): {
                            puzzleRoom = "codeRoom";
                            break;
                        }
                    }
                    puzzleRoom = "alchemyRoom";
                }
                break;
            }
            case(this.atlas.id[0]):
            {
                if(this.objects[3].locked === true) {
                    gotBook = true;
                    printData("As you pick up the book that says atlas you feel the room shake",action);
                    printData("Suddenly the rest of the books disappear and you hear a click by the back door",action);
                    printData("\"CLICK\"",saying);
                    playerBook = this.atlas.id[0];
                    inventory.pickUp(this.atlas.id[0]);

                    inventory.removeImage(inventory.getItemData(this.alchemy.id[0]));
                    inventory.getItemData(this.alchemy.id[0]).pickedUp = true;

                    inventory.removeImage(inventory.getItemData(this.cryptography.id[0]));
                    inventory.getItemData(this.cryptography.id[0]).pickedUp = true;
                    this.objects[3].locked = false;


                    let random = Math.floor(Math.random() * 2);
                    //printData(random,saying);
                    switch (random) {
                        case(0): {
                            puzzleRoom = "alchemyRoom";
                            break;
                        }
                        case(1): {
                            puzzleRoom = "codeRoom";
                            break;
                        }
                    }
                    puzzleRoom = "mazeRoom";
                }
                break;
            }
            default:
            {
                printPickUpError();
            }
        }
        if(gotBook)
        {
            var request = new XMLHttpRequest();
            if (!request) {
                alert("ERROR");
                return false;
            }
            request.onreadystatechange =async() => {
            }
            var url = "/post/book/";
            request.open('POST', url, true);
            request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            request.send('Book='+playerBook);
        }
    }
}