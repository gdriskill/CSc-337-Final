/**
 * File name: BarnClass.js
 * Assignment: Final Project CSC 337
 * Purpose: Creates the class for the barn location. Here the player can pick up 
 *      the house key and bread. Contains all the objects located in the room, 
 *      and what happens when the user moves, interacts or looks at these objects.
 */
class barn extends tempClass {
    name = "barn";

    // all the objects in this room
    houseKey = inventory.getItemData("Front House Key");
    bread = inventory.getItemData("Bread");
    objects = [this.bread,this.houseKey,this.exit];

    /**
     * Updates this room when the game loads, so all the conditions of the room are correct
     * even after a player leaves the room and returns later.
     */
    updateLocation()
    {
        this.houseKey = inventory.getItemData("Front House Key");
        this.bread = inventory.getItemData("Bread");
        this.objects = [this.bread,this.houseKey,this.exit];
    }

    image = "../images/BarnInside.png";

    /**
     * Handles cases for when a player tries to look at a specified item
     * in the room
     * @param {*} item      The item the player has clicked on
     */
    look(item){
        switch(item)
        {
            case(this.bread.id[0]):{
                if(!inventory.hasItem(this.bread.id[0]))
                {
                    printData("Its a whole loaf of bread",thought);

                }
                break;
            }
            case(this.houseKey.id[0]):
            {
                if(!inventory.hasItem(this.houseKey.id[0]))
                {
                    printData("It look like a key on the floor",thought);

                }
                break;
            }

            case("default"):
            {
                printData("Its an old wooden barn",thought);
                if(!inventory.hasItem(this.bread.id[0]))
                {
                    printData("You look down and notice something strange",thought);
                    printData("There is a loaf of bread on the ground.",thought);
                    if(!inventory.hasItem(this.houseKey.id[0]))
                    {
                        printData("You also see something shining",thought);
                    }
                }
                else
                {
                    printData("There used to be a loaf of bread on the ground.",thought);
                    printData("Now its mine.",thought);
                    if(!inventory.hasItem(this.houseKey.id[0]))
                    {
                        printData("You still see something shining on the floor",thought);
                    }
                }
                break;
            }
            default:{
                printData("I dont understand what you want me to look at",thought);
                break;
            }
        }
    }

    /**
     * Handles cases for when a player moves to a specified location in the 
     * room. 
     * @param {*} location  The location player has clicked on 
     */
    move(location)
    {
        switch(location){
            case("exit"):
            {
                printData("You leave the barn", action);
                travel("outside");
                break;
            }
            default:{
                printMoveError();
            }
        }
    }

    /**
     * Handles cases for when a player interacts with a specified item in the 
     * room.
     * @param {*} item      the item from the room the player is trying to 
     *                      interact with
     */
    interact(item){
        switch(item)
        {
            //Bread
            case(this.bread.id[0]):{
                inventory.pickUp(this.bread.id[0]);
                break;
            }
            case(this.houseKey.id[0]):{
                inventory.pickUp(this.houseKey.id[0]);
                break;
            }
            default:
            {
                printPickUpError();
                break;
            }
        }

    }
}