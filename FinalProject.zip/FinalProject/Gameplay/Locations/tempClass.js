class tempClass {
    name = "Temp";
    objects;
    exit = {id: ["exit"], locked: false, occupies: [1,2,3,4,5,6,7,8, 9,17,25,33,41,49 ,16,24,32,40,48,56 ,57,58,59,60,61,62,63,64]};

    updateLocation(){}
    getObjects() {
        return this.objects;
    }
    look(item){printData("I dont see anything",error);}
    interact(item){ printPickUpError();}
    itemInteract(playerItem,item){
        printData("I'm not using this on that",error);
    }
    move(location){printMoveError();}
}
