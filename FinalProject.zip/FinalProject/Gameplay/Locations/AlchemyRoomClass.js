/**
 * File name: AlchemyRoomClass.js
 * Assignment: Final Project CSC 337
 * Purpose: Creates the class for the alchemy room. From this room, the 
 *      player can travel to the alchemy table and solve the puzzle that goes 
 *      with the alchemy book, and interact with the marketplace. Contains 
 *      all the objects located in the room, and what happens when the user 
 *      moves, interacts or looks at these objects.
 */
class alchemyRoom extends tempClass {
    name = "alchemyRoom";

    // all the objects in this room
    tradePit = {id: ["tradePit"], occupies: [53,54,55,45,46,47]}
    badEndingDoor = {id: ["badEndingDoor"], occupies: [18,19,26,27,34,35,42,43]}

    goodEndingDoor = {id: ["goodEndingDoor"], occupies: [21,22,23,29,30,31,37,38,39]}

    alchemyTable = {id: ["alchemyTable"], occupies: [35,36,43,44]}

    objects = [this.goodEndingDoor,this.alchemyTable,this.badEndingDoor,this.tradePit,this.exit];

    // background image
    image = "../images/AlchemyRoom.png";

    /**
     * Handles cases for when a player moves to a specified location in the 
     * room. 
     * @param {*} location  The location player has clicked on 
     */
    move(location) {
        switch (location) {
            case("exit"): {
                travel("hallway");
                break;
            }
            case(this.alchemyTable.id[0]):
            {
                if(inventory.hasItem("Alchemy Book"))
                {
                    travel("alchemyTable");
                }
                else
                {
                    printData("It's an alchemy table, I don't know alchemy",thought);
                    printData("If only I picked up that alchemy book in the other room. There must be another way for me to get it",thought);
                }
                break;
            }
            case(this.badEndingDoor.id[0]):{
                if(confirm("Are you sure?\nThis option will end the game."))
                {
                    travel("ending");
                }
                break;
            }
            default:{
                printMoveError();
            }
        }
    }

    /**
     * Handles cases for when a player tries to interact on an object with something
     * from their inventory.
     * @param {*} playerItem    the item the player is using from their inventory
     * @param {*} item      the item in the room the player in interacting on
     */
    itemInteract(playerItem, item) {
        switch (item){
            case(this.goodEndingDoor.id[0]):{
                if(playerItem === inventory.curePotion.id[0])
                {
                    printData("You win");
                    travel("outside").then(()=>newGameLoad());
                }
                break;
            }
            default:{
                printData("I'm not using this on that",error);
                break;
            }
        }
    }

    /**
     * Handles cases for when a player interacts with a specified item in the 
     * room.
     * @param {*} item      the item from the room the player is trying to 
     *                      interact with
     */
    interact(item) {
        switch (item){
            case(this.tradePit.id[0]):
            {
                if(confirm("Open market place?"))
                {
                    this.goToMarketPlace();
                }
                break;
            }
            default:{
                printPickUpError();
            }
        }
    }
    
    /**
     * Sends a player to the market place. This function is ran when the user 
     * click on the trading pit in the room.
     */
    goToMarketPlace()
    {
        var request = new XMLHttpRequest();
        if (!request) {
            alert("ERROR");
            return false;
        }
        request.onreadystatechange =async() => {
            if (request.readyState === XMLHttpRequest.DONE) {
                this.openMarketPlace();
            }

        }

        let playGame = "market";
        let playHappy = "true";
        var url = "/play/game/";
        request.open('POST', url, true);
        request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        request.send('playGame='+playGame+"&playHappy="+playHappy);
    }

    /**
     * Opens up the market place screen
     */
    openMarketPlace(){
        var urlAll = "/market";
        var requestAll = new XMLHttpRequest();
        if (!requestAll) {
            alert("ERROR");
            return false;
        }
        requestAll.onreadystatechange = () => {
            if (requestAll.readyState === XMLHttpRequest.DONE) {
                if (requestAll.status === 200) {
                    saveGameData().then(()=>{window.location.href ="market";});
                } else {
                    alert("ERROR");
                }
            }
        }
        requestAll.open('GET', urlAll, true);
        requestAll.send();
    }
}