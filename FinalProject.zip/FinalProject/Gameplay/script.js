
const action = "action";
const error = "error";
const saying = "saying";
const thought = "thought";

let playerBook;
let puzzleRoom;
let currentMix = [];
let currentPath = 0;

let outsideLocation = new outside();
let barnLocation = new barn();
let frontHouseLocation = new frontOfHouse();
let enterPuzzleRoom = false;
let bookRoomLocation = new bookRoom();
let hallWayLocation = new hallway();
let kitchenLocation = new kitchen();
let bathroomLocation = new bathroom();
let livingRoomLocation = new livingRoom();
let bedroomLocation = new bedroom();
let alchemyRoomLocation = new alchemyRoom();
let alchemyTableLocation = new alchemyTableClass();
let mazeRoomLocation = new mazeRoom();
let codeRoomLocation = new codeRoom();
let mazeAreaLocation = new mazeArea();

let playerInventory = inventory;


let playerInput = new userController();

//Start New Game values
let currentLocationData = outsideLocation;
let currentLocation = currentLocationData.name;

let currentItem = "";
let imageInput = "";

 function getInput(){
// console.log("Hey");
//     document.getElementById("userInput").onkeydown = function (e){
//         let userInput = document.getElementById("userInput").value.trim();
//         if(!e) {e = window.event;}
//         var keyCode = e.code || e.key;
//         if(keyCode === 'Enter'){
//             document.getElementById("userInput").value = "";
//
//             printData(userInput,action);
//
//             let inputType = playerInput.getInputType(userInput);
//             let objectType = playerInput.getItemType(currentLocationData.getObjects(),userInput);
//
//             gameCommand(inputType, objectType);
//         }
//     }
 }

async function gameCommand(inputType, objectType)
{
    //Send to server

    //Load from server
    //let infoFromServer = JSON.parse(JSON.stringify(areaInfo));

    //outsideLocation.objects = infoFromServer.outsideLocation
    //barnLocation.objects = infoFromServer.barnLocation

    //console.log(JSON.parse(JSON.stringify(outsideLocation)));
    console.log("Item:"+currentItem);
    console.log(inputType+" "+objectType);
        const myPromise = new Promise((resolve, reject) =>{
        switch (inputType) {
            case("look"): {
                currentLocationData.look(objectType)
                break;
            }
            case("grab"): {
                let item = currentLocationData.interact(objectType);
                updateMouse("grab");
                break;
            }
            case("move"): {
                currentLocationData.move(objectType)
                break;
            }
            case("itemInteract"): {
                currentLocationData.itemInteract(currentItem, objectType);
                break;
            }
            default: {
                printData("I dont know what you are talking about", thought);
                break;
            }
        }
            resolve('Done:>');
    }
);
        myPromise.then(function (){saveGameData();});
        currentLocationData.updateLocation();
    console.log("After Command:");
    console.log(barnLocation.objects);
}
function updateMouse(type)
{
    for(let i = 0; i < currentLocationData.objects.length; i++)
    {
        for(let j =0; j < currentLocationData.objects[i].occupies.length; j++)
        {
            if(!currentLocationData.objects[i].pickedUp) {
                document.getElementById("i" + currentLocationData.objects[i].occupies[j]).style.cursor = type;
            }
            else
            {
                document.getElementById("i" + currentLocationData.objects[i].occupies[j]).style.cursor = "";
            }
        }
    }
}

//This will set the selection for the current interaction
function setSelection(selection){

     //Sets all interactions to blank
    document.getElementById("interact").style.background = "";
    document.getElementById("move").style.background = "";
    document.getElementById("look").style.background = "";

    //Sets all item interactions to blank
    let inventoryItems = document.getElementsByClassName("playerItem");
    for(let i = 0; i<inventoryItems.length; i++) {
        document.getElementsByClassName("playerItem")[i].style.background = "";
    }

    console.log("Test: "+selection);
    //Test which interaction is selected
    switch (selection)
    {
        //Interaction Look
        case("look"): {
            document.getElementById(selection).style.background = "red";
            currentItem = "";
            updateMouse("zoom-in");
            imageInput = "look";
            break;
        }
        //Interaction interact
        case("interact"):{
            document.getElementById(selection).style.background = "red";
            currentItem = "";
            updateMouse("grab");
            imageInput = "grab";
            break;
        }
        //Interaction move
        case("move"):{
            document.getElementById(selection).style.background = "red";
            currentItem = "";
            updateMouse("crosshair");
            imageInput = "move";
            break;
        }
        //Interaction none
        case(null):
        case(""):{
            currentItem = "";
            updateMouse("");
            imageInput = "";
            break;
        }
        //Interaction inventory item
        default:{
            if(inventory.itemData(selection) !== undefined)
            printData(inventory.itemData(selection),thought);
            document.getElementById(selection).style.background = "red";
        }
    }
}
function loadGameData()
{
    console.log("Default:");
    console.log(barnLocation.objects);
    //playerInventory = inventory;

    console.log("LOADING!")
    var url = "/load/game/data";
    var request = new XMLHttpRequest();
    if (!request) {
        alert("ERROR");
        return false;
    }
    request.onreadystatechange = async () => {
        if (request.readyState === XMLHttpRequest.DONE) {
            if (request.status === 200) {
                var data = JSON.parse(request.response);
                setGameData(data).then(()=>{
                    loadGame().then(()=>{
                        inventory.updateInventory();
                            document.getElementById("loading").remove();

                    });
                });
                await updateMouse("");
            } else {
                alert("ERROR");
            }
        }
    }
    request.open('GET', url, true);
    request.send();
}

async function setGameData(infoFromServer)
{
    console.log("Default:");
    console.log(barnLocation.objects);
    playerBook = infoFromServer.playerBook;
    puzzleRoom = infoFromServer.puzzleRoom;

    inventory.itemInfo = await infoFromServer.inventory;


    outsideLocation.objects = await infoFromServer.outsideLocation;
    barnLocation.objects =  infoFromServer.barnLocation;
    frontHouseLocation.objects = await infoFromServer.frontHouseLocation;
    enterPuzzleRoom.objects = await infoFromServer.enterPuzzleRoom;
    bookRoomLocation.objects = await infoFromServer.bookRoomLocation;
    hallWayLocation.objects = await infoFromServer.hallWayLocation;
    kitchenLocation.objects = await infoFromServer.kitchenLocation;
    bathroomLocation.objects = await infoFromServer.bathroomLocation;
    livingRoomLocation.objects = await infoFromServer.livingRoomLocation;
    bedroomLocation.objects = await infoFromServer.bedroomLocation;
    alchemyRoomLocation.objects = await infoFromServer.alchemyRoomLocation;
    alchemyTableLocation.objects = await infoFromServer.alchemyTableLocation;
    mazeRoomLocation.objects = await infoFromServer.mazeRoomLocation;
    codeRoomLocation.objects = await infoFromServer.codeRoomLocation;

    currentLocationData = await infoFromServer.currentLocation;
    currentLocation = currentLocationData.name;
    console.log("Objects Updated")
    console.log("Save File:");
    console.log(barnLocation.objects);
}


async function saveBook()
{
    var request = new XMLHttpRequest();
    if (!request) {
        alert("ERROR");
        return false;
    }
    request.onreadystatechange =async() => {
    }

    var url = "/post/book/";
    request.open('POST', url, true);
    request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    await request.send('playerData='+areaInfo);
}


async function saveGameData()
{
    console.log("SAVING!");
    let areaInfo = JSON.stringify({
        playerBook: playerBook,
        puzzleRoom: puzzleRoom,
        inventory: inventory.itemInfo,
        currentLocation: currentLocationData,
        outsideLocation: outsideLocation.objects,
        barnLocation:barnLocation.objects,
        frontHouseLocation:frontHouseLocation.objects,
        enterPuzzleRoom :enterPuzzleRoom.objects,
        bookRoomLocation:bookRoomLocation.objects,
        hallWayLocation :hallWayLocation.objects,
        kitchenLocation :kitchenLocation.objects,
        bathroomLocation :bathroomLocation.objects,
        livingRoomLocation :livingRoomLocation.objects,
        bedroomLocation :bedroomLocation.objects,
        alchemyRoomLocation :alchemyRoomLocation.objects,
        alchemyTableLocation :alchemyTableLocation.objects,
        mazeRoomLocation:mazeRoomLocation.objects,
        codeRoomLocation :codeRoomLocation.objects});

    var request = new XMLHttpRequest();
    if (!request) {
        alert("ERROR");
        return false;
    }
    request.onreadystatechange =async() => {
    }

    var url = "/save/game/";
    request.open('POST', url, true);
    request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    await request.send('playerData='+areaInfo);

}

async function newGameLoad()
{
     playerBook = "";
     puzzleRoom = "";
     currentMix = [];
     currentPath = 0;

     outsideLocation = new outside();
     barnLocation = new barn();
     frontHouseLocation = new frontOfHouse();
     enterPuzzleRoom = false;
     bookRoomLocation = new bookRoom();
     hallWayLocation = new hallway();
     kitchenLocation = new kitchen();
     bathroomLocation = new bathroom();
     livingRoomLocation = new livingRoom();
     bedroomLocation = new bedroom();
     alchemyRoomLocation = new alchemyRoom();
     alchemyTableLocation = new alchemyTableClass();
     mazeRoomLocation = new mazeRoom();
     codeRoomLocation = new codeRoom();
     mazeAreaLocation = new mazeArea();
    setSelection("");
    inventory.removeImageLocation(currentLocationData.name);

     currentLocationData = outsideLocation;
     currentLocation = currentLocationData.name;
     inventory = new userItem();
     inventory.updateInventory();
     inventory.setImages(currentLocationData.name);
     loadGame();

    console.log(inventory);
     playerInput = new userController();
    setSelection("");
    //Start New Game values
     //currentLocationData = outsideLocation;
     //currentLocation = currentLocationData.name;
    //currentLocationData.look("default");

     currentItem = "";
     imageInput = "";
    updateMouse("");

}

//This will select the item in the inventory (When user clicks on item in inventory)
function selectItem(item)
{
    //Colors the item
    setSelection(item);

    //sets the mouse icons
    updateMouse("grabbing");

    //Sets the current item
    currentItem = item;

    //Sets the input type
    imageInput="itemInteract";
}

function imageClick(imageLocation)
{
    // alert("Click");

    // document.getElementById('chatBox').scrollTop();
    if(!(imageInput === ""))
    {
        let intImageLocation = parseInt(imageLocation.substring(1));
        // document.getElementById(imageLocation).style.background = "green";
        //document.getElementById(imageLocation).style.opacity = 1;
        let object = playerInput.lookLocation(currentLocationData.getObjects(),intImageLocation);

        gameCommand(imageInput,object);
        var element = document.getElementById('chatBox');
        element.scrollTop = element.scrollHeight;
    }

}
function printMoveError()
{
    let printedMessage = document.createElement("div");
    printedMessage.innerText = "I can't go there";
    printedMessage.id = error;
    document.getElementById("chatBox").appendChild(printedMessage);
}

function printPickUpError()
{
    //console.log("Message: "+message+" Id: "+itemId);
    let printedMessage = document.createElement("div");
    printedMessage.innerText = "I can't pick that up";
    printedMessage.id = error;
    document.getElementById("chatBox").appendChild(printedMessage);
}

function printData(message, itemId){
    console.log("Message: "+message+" Id: "+itemId);
    let printedMessage = document.createElement("div");
    printedMessage.innerText =message;
    printedMessage.id = itemId;

    document.getElementById("chatBox").appendChild(printedMessage);
    var element = document.getElementById('chatBox');

    element.scrollTop = element.scrollHeight;
    return "done";
}

async function loadGame() {
    preloadimages(bookRoomLocation.image);
    switch (currentLocation) {
        case(outsideLocation.name): {
            await (currentLocationData = outsideLocation);
            document.body.style.backgroundColor = "#020a02";
            break;
        }
        case(barnLocation.name): {
            await (currentLocationData = barnLocation);
            document.body.style.backgroundColor = "#0c0303";
            break;
        }
        case(frontHouseLocation.name): {
            await (currentLocationData = frontHouseLocation);
            document.body.style.backgroundColor = "#0c0303";
            break;
        }
        case(bookRoomLocation.name): {
            currentLocationData = await bookRoomLocation;
            document.body.style.backgroundColor = "#000205";
            break;
        }
        case(hallWayLocation.name): {
            await (currentLocationData = hallWayLocation);
            document.body.style.backgroundColor = "#03090c";
            break;
        }
        case(kitchenLocation.name): {
            await (currentLocationData = kitchenLocation);
            document.body.style.backgroundColor = "#03090c";
            break;
        }
        case(bathroomLocation.name): {
            await (currentLocationData = bathroomLocation);
            document.body.style.backgroundColor = "#03090c";
            break;
        }
        case(livingRoomLocation.name): {
            await (currentLocationData = livingRoomLocation);
            document.body.style.backgroundColor = "#03090c";
            break;
        }
        case(bedroomLocation.name): {
            await (currentLocationData = bedroomLocation);
            document.body.style.backgroundColor = "#03090c";
            break;
        }
        case(alchemyRoomLocation.name): {
            await (currentLocationData = alchemyRoomLocation);
            document.body.style.backgroundColor = "#03090c";
            break;
        }
        case(mazeRoomLocation.name): {
            await (currentLocationData = mazeRoomLocation);
            document.body.style.backgroundColor = "#03090c";
            break;
        }
        case(codeRoomLocation.name): {
            await (currentLocationData = codeRoomLocation);
            document.body.style.backgroundColor = "#03090c";
            break;
        }
        case(alchemyTableLocation.name): {
            await (currentLocationData = alchemyTableLocation);
            document.body.style.backgroundColor = "#03090c";
            break;
        }
        case(mazeAreaLocation.name):{
            await (currentLocationData = mazeAreaLocation);
            document.body.style.backgroundColor = "#03090c";
            break;
        }
    }

    console.log("HELLO?");
    console.log(currentLocationData.image);
    document.getElementById("backgroundImage").src = currentLocationData.image;
    inventory.setImages(currentLocationData.name);
    currentLocationData.updateLocation();
    currentLocationData.look("default");
}



function preloadimages(myimages){
    for (i=0;i<preloadimages.arguments.length;i++){
        myimages[i]=new Image()
        myimages[i].src=preloadimages.arguments[i]
    }
}

async function travel(locationToTravel)
{
    inventory.removeImageLocation(currentLocationData.name);
    updateMouse("");
    currentLocation = locationToTravel;
    loadGame();
    updateMouse("crosshair");
}

