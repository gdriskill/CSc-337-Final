/**
 * File name: PlayItems.js
 * Assignment: Final Project CSC 337
 * Purpose: Creates the class for all the possible objects a player
 *      could have in their inventory. An instance of this class 
 *      represents a user's inventory. 
 */
class userItem {
    // all items in the game that could be in the user's inventory
    curePotion = {id: ["Cure Potion"], pickedUp: false, occupies: [15],location: "",imgLoc: "../images/CurePotion.png",inInventory:false};
    bluePotion = {id: ["Blue Potion"], pickedUp: false, occupies: [10],location: "alchemyTable",imgLoc: "../images/BluePotion.png",inInventory:false};
    redPotion = {id: ["Red Potion"], pickedUp: false, occupies: [12],location: "alchemyTable",imgLoc: "../images/RedPotion.png",inInventory:false};
    greenPotion = {id: ["Green Potion"], pickedUp: false, occupies: [15],location: "alchemyTable",imgLoc: "../images/GreenPotion.png",inInventory:false};
    breadData = {id: ["Bread"], pickedUp: false, occupies: [52],location: "barn",imgLoc: "../images/bread.png",inInventory:false};
    mysteryKeyData = {id: ["Mystery Key"], pickedUp: false, occupies: [46],location: "",imgLoc: "../images/frontHouseKey.png",inInventory:false};
    frontHouseKeyData = {id: ["Front House Key"], pickedUp: false, occupies: [55],location: "barn",imgLoc: "../images/frontHouseKey.png",inInventory:false};
    bookAtlas = {id: ["Atlas Book"], pickedUp: false, occupies: [44],location: "bookRoom",imgLoc: "../images/book.png",inInventory:false};
    alchemyBook = {id: ["Alchemy Book"], pickedUp: false, occupies: [45],location: "bookRoom",imgLoc: "../images/book.png",inInventory:false};
    cryptographyBook = {id: ["Cryptography Book"], pickedUp: false, occupies: [46],location: "bookRoom",imgLoc: "../images/book.png",inInventory:false};
    tomogotchi = {id: ["Tomogotchi"], pickedUp: true, occupies: [46],location: "bookRoom",imgLoc: "../images/tomogotchi.png",inInventory:true};

    itemInfo = [this.curePotion,this.bluePotion,this.redPotion,this.greenPotion,this.breadData,this.mysteryKeyData,this.frontHouseKeyData,this.bookAtlas,this.alchemyBook,this.cryptographyBook,this.tomogotchi];


    /**
     * Returns the data for a specified data. This is the text description
     * of the item printed to the user
     * @param name  name of item to get data of
     * @returns     the data for the specified item
     */
    getItemData(name) {
        for (let i = 0; i < this.itemInfo.length; i++) {
            console.log(this.itemInfo[i].id[0])
            console.log(name)
            if (this.itemInfo[i].id[0] === name) {
                console.log(this.itemInfo[i]);
                return this.itemInfo[i];
            }
        }
    }

    /**
     * Updates the inventory, so when the game loads all the items have
     * the correct conditions.
     */
    updateInventory()
    {
        for (let i = 0; i < this.itemInfo.length; i++) {
            if (this.itemInfo[i].inInventory) {
                this.addItemToInventory(this.itemInfo[i]);
            }
            else
            {
                this.removeItem(this.itemInfo[i].id[0]);
            }
        }
        this.curePotion = this.itemInfo[0];
        this.bluePotion = this.itemInfo[1];
        this.redPotion = this.itemInfo[2];
        this.greenPotion = this.itemInfo[3];
        this.breadData = this.itemInfo[4];
        this.mysteryKeyData = this.itemInfo[5];
        this.frontHouseKeyData = this.itemInfo[6];
        this.bookAtlas = this.itemInfo[7];
        this.alchemyBook = this.itemInfo[8];
        this.cryptographyBook = this.itemInfo[9];
        this.tomogotchi = this.itemInfo[10];

    }

    /**
     * Lets a user pick up an item, but doesn't check if its 
     * already picked up and doesn't print out a message.
     * @param  item     name of the item to pick up 
     * @returns true if the item is sucessfully picked up
     */
    pickUpMagic(item)
    {
        let currentItem = this.getItemData(item);
            currentItem.pickedUp = true;
            currentItem.inInventory = true;
            this.removeImage(currentItem);
            this.addItemToInventory(currentItem);
            return true;
    }

    /**
     * Handles when a user tries to pick up an item. If the item
     * isn't already picked up, that item is marked as picked up
     * and added to the player's inventory. A message of this is
     * printed to the user
     * @param item  name of the item to pick up 
     * @returns true if the item is sucessfully picked up
     */
    pickUp(item) {
        let currentItem = this.getItemData(item);
        if (!currentItem.pickedUp) {
            printData("You picked up the " + currentItem.id[0].toLowerCase(), action)
            currentItem.pickedUp = true;
            currentItem.inInventory = true;
            this.removeImage(currentItem);
            this.addItemToInventory(currentItem);
            return true;
        }
        printPickUpError();
        return false;
    }

    /**
     * Removes an item from the user's inventory
     * @param item  item to remove
     */
    removeItem(item)
    {
        console.log("\""+item+"\"");
        let currentItem = this.getItemData(item);
        if(currentItem !== undefined)
        {
            currentItem.inInventory = false;
            // this.getItemData(item).pickedUp = false;
            if(document.getElementById(item)!==null){
                document.getElementById(item).remove();
            }
        }

    }

    /**
     * User uses an item. Removes it from their inventory
     * and sets it as selected
     * @param item  the item to use
     */
    useItem(item)
    {
        this.removeItem(item);
        setSelection("");
    }

    /**
     * Returns true if the user has this item in their inventory
     * @param item  name of item to check
     * @returns true if the user has this item in their inventory
     */
    hasItem(item) {
        return this.getItemData(item).inInventory;
    }

    /**
     * Places an item in the user's inventory. Image of item appears
     * in inventory section on screen
     * @param  item     item to put in inventory
     */
    addItemToInventory(item)
    {
        let playersItem = document.createElement("img");
        playersItem.id = item.id;
        playersItem.src = item.imgLoc;
        playersItem.className = "playerItem";
        playersItem.title=item.id;
        playersItem.setAttribute('onclick',"selectItem(id);");
        document.getElementById("inventoryInside").appendChild(playersItem);
        var element = document.getElementById('inventoryInside');
        element.scrollTop = element.scrollHeight;
    }

    /**
     * Takes the specified item's image off the screen
     * @param  item  name of item to remove image of
     */
    removeImage(item)
    {
        document.getElementById("i"+item.occupies).style.opacity = 0;
        document.getElementById("i"+item.occupies).src = "";

    }

    /**
     * Takes the image in the specified location of the screen,
     * if there's an item there
     * @param location location of image to remove
     */
    removeImageLocation(location)
    {
        for (let i = 0; i < this.itemInfo.length; i++) {
            if (this.itemInfo[i].location === location)
            {
                document.getElementById("i"+this.itemInfo[i].occupies[0]).style.opacity = 0;
                document.getElementById("i"+this.itemInfo[i].occupies[0]).src = "";
            }
        }
    }

    /**
     * Adds image to screen if the image isn't picked up
     * @param location  location of image 
     */
    setImages(location) {
        for (let i = 0; i < this.itemInfo.length; i++) {
            if (this.itemInfo[i].location === location && !this.itemInfo[i].pickedUp)
            {
                document.getElementById("i"+this.itemInfo[i].occupies[0]).src = this.itemInfo[i].imgLoc;
                document.getElementById("i"+this.itemInfo[i].occupies[0]).style.opacity = .8;

            }
        }
    }

    /**
     * Figures out the data for an item. This is a description of the
     * item
     * @param  item     name of item to find data of
     * @returns String, the item's data
     */
    itemData(item)
    {
        switch(item){
            case(this.bookAtlas.id[0]):{
                if(puzzleRoom === "mazeRoom")
                {
                    let printedMessage = document.createElement("div");
                    printedMessage.innerHTML = "An Atlas <i>for poets </i><br> <br>\n" +
                        "                        It seems your maze has no way out <br>\n" +
                        "                        But with some help, you can find a route <br>\n" +
                        "                        Please follow this advice <br>\n" +
                        "                        Or pay the price. <br>\n" +
                        "                        <br>\n" +
                        "                            At your first choice, go left <br>\n" +
                        "                            This just begins your quest. <br>\n" +
                        "                            Then, you must turn right <br>\n" +
                        "                            Continue with grace and might <br>\n" +
                        "                            <br>\n" +
                        "                                Now, to follow your fate <br>\n" +
                        "                                Don't turn. Keep on straight <br>\n" +
                        "                                <br>\n" +
                        "                                    Do you feel you have the hang out it? <br>\n" +
                        "                                    Up ahead, you'll see the path again split <br>\n" +
                        "                                    <br>\n" +
                        "                                        You should veer left my friend <br>\n" +
                        "                                        and then, do it again! <br>\n" +
                        "                                        <br>\n" +
                        "                                            At this point end is near <br>\n" +
                        "                                            And the choice is clear <br>\n" +
                        "                                            <br>\n" +
                        "                                                You mustn’t change course <br>\n" +
                        "                                                Go forward with force <br>";
                    printedMessage.id = action;
                    document.getElementById("chatBox").appendChild(printedMessage);
                }
                else
                {
                    return "It an old book and it says the word \"Atlas\" on the front";
                }
                break;
            }


            case(this.frontHouseKeyData.id[0]):{
                return "Seems to be the key for the front door";
                break;
            }



            case(this.alchemyBook.id[0]):{
                if(puzzleRoom === "alchemyRoom")
                {
                    let printedMessage = document.createElement("div");
                    printedMessage.innerHTML = "The Ol' Witches Book of Potions and Brews\n" +
                        "                <br> <br>\n" +
                        "                \"Cure potion\"\n" +
                        "                <br> <br>\n" +
                        "                Drinking this potion grants immunity against various poisons including but not limited\n" +
                        "                    to poison vines, poison frogs, respiratory poisons and potions spells.\n" +
                        "                    <br> <br>\n" +
                        "                        Ingredients: <br>\n" +
                        "                        Dragon blood (to a layman's eye, this may look like a <b>red potion</b>) <br>\n" +
                        "                        Liquified fairy wings (to a layman's eye, this may look like a <b>blue potion</b>) <br>\n" +
                        "                        Juiced turtle meat (to a layman's eye, this may look like a <b>green potion</b>)\n" +
                        "                        <br> <br>\n" +
                        "                            Steps: <br>\n" +
                        "                            *Please note, you must absolutely follow these steps in exact order... magic is a science after all <br>\n" +
                        "                            1. Locate an alchemy table <br>\n" +
                        "                            2. Add one vile of dragon blood <br>\n" +
                        "                            3. Add yet another vile of dragon blood <br>\n" +
                        "                            4. Add one vile of liquified fairy wings <br>\n" +
                        "                            5. Add one vile of juiced turtle meat <br>\n" +
                        "                            6. Add another vile of liquified fairy wings <br>";
                    printedMessage.id = action;
                    document.getElementById("chatBox").appendChild(printedMessage);
                }
                else
                {
                    return "It an old book and it says the word \"Alchemy\" on the front";
                }

                break;
            }

            case(this.cryptographyBook.id[0]):{
                if(puzzleRoom === "codeRoom")
                {
                    let printedMessage = document.createElement("div");
                    printedMessage.innerHTML = "The code is \n" +
                        "☺♥♣♫";
                    printedMessage.id = action;
                    printData("However, the lock only take in number. I'll have to find a way to LOOK UP the numeric codes to type keyboard symbols.",thought);
                    printData("IF ONLY I HAD ACCESS TO ALL OF HUMAN KNOWLEDGE AT MY FINGERTIPS RIGHT NOW (HINT!!)",thought);
                    document.getElementById("chatBox").appendChild(printedMessage);
                }
                else
                {
                    return "It an old book and it says the word \"Cryptography\" on the front";
                }

                break;
            }
            case(this.breadData.id[0]):{
                return "A whole loaf of bread";
                break;
            }
            case(this.mysteryKeyData.id[0]):{
                return "Seems like the key to the door in the hallway";
                break;
            }
            case(this.tomogotchi.id[0]):{
                var url = "/tamagachi";
                var request = new XMLHttpRequest();
                if (!request) {
                    alert("ERROR");
                    return false;
                }
                request.onreadystatechange = () => {
                    if (request.readyState === XMLHttpRequest.DONE) {
                        if (request.status === 200) {
                            window.location = "../tamagachi"
                        } else {
                            alert("ERROR");
                        }
                    }
                }
                request.open('GET', url, true);
                request.send();
            }
        }
    }
}

// ititialize an istance of userItem for the user's inventory
let inventory = new userItem();