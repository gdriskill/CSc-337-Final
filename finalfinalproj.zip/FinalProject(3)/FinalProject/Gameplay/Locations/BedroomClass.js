/**
 * File name: BedroomClass.js
 * Assignment: Final Project CSC 337
 * Purpose: Creates the class for the bedroom location. Contains all the objects 
 *      located in the room, and what happens when the user moves, interacts or
 *      looks at these objects.
 */
class bedroom extends tempClass {
    name = "bedroom";
    
    // objects in this room
    container = {id: ["container"], locked: false, occupies: [46]}
    objects = [this.container,this.exit];

    image = "../images/Bedroom.png";

    /**
     * Handles cases for when a player moves to a specified location in the 
     * room. 
     * @param {*} location  The location player has clicked on 
     */
    move(location) {
        switch (location) {
            case("exit"): {
                travel("hallway");
            }
        }
    }

    /**
     * Handles cases for when a player tries to look at a specified item
     * in the room
     * @param {*} item      The item the player has clicked on
     */
    look(item) {
        switch (item){
            case(this.container.id[0]):{
                printData("Looks like an old bag",thought);
                printData("Might be something useful in it",thought);
            break;
            }
            default:
            {
                printData("It's an old bedroom",thought);
                printData("Seems like the bed has collapsed",thought);
                printData("There also seems to be a bag on the bed",thought);
            break;
            }
        }
    }

    /**
     * Handles cases for when a player interacts with a specified item in the 
     * room.
     * @param {*} item      the item from the room the player is trying to 
     *                      interact with
     */
    interact(item) {
        switch (item){
            case(this.container.id[0]):
            {
                if(inventory.pickUp("Mystery Key")){
                    printData("You search through the bag and find a strange key",thought)
                }
                else
                {
                    printData("There's nothing else in the bag worth taking",thought)
                }
                break;
            }
        }
    }
}