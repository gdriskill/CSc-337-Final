/**
 * File name: FrontHouseClass.js
 * Assignment: Final Project CSC 337
 * Purpose: Creates the class for the front house location. Contains all the objects 
 *      located in the room, and what happens when the user moves, interacts or looks
 *      at these objects.
 */

class frontOfHouse extends tempClass{
    name = "frontOfHouse";
    //objects in this room
    houseDoor = {id: ["houseDoor"], locked: true, occupies: [12,13,20,21,28,29,36,37,44,45,52,53]}
    objects = [this.houseDoor,this.exit];

    image = "../images/FrontDoor.png";

    /**
     * Handles cases for when a player tries to look at a specified item
     * in the room
     * @param {*} item      The item the player has clicked on
     */
    look(item)
    {
        switch (item){
            default:
            case("default"):{
                printData("It an old wooden door",thought);
                break;
            }
        }
    }

    /**
     * Handles cases for when a player moves to a specified location in the 
     * room. 
     * @param {*} location  The location player has clicked on 
     */
    move(location)
    {
        switch(location){
            case(this.houseDoor.id[0]):
            {
                if(this.objects[0].locked)
                {
                    printData("You turn the door handle but it doesn't move", action);
                    printData("I can't enter the house the door is locked", thought);
                }
                else
                {
                    printData("You turn the handle of the door and enter the house", action);
                    travel("bookRoom");
                    printData("The door closes behind you and you hear a click noise", action);
                }
                break;
            }
            case("exit"):
            {
                printData("You leave the front of the house", action);
                travel("outside");
                break;
            }
            default:{
                printMoveError();
            }
        }
    }

    /**
     * Handles cases for when a player tries to interact on an object with something
     * from their inventory.
     * @param {*} playerItem    the item the player is using from their inventory
     * @param {*} item      the item in the room the player in interacting on
     */
    itemInteract(item, gameObject)
    {
    switch(gameObject){
        case(this.houseDoor.id[0]):
        {
            if(item === "Bread")
            {
                printData("You push the bread into the door",action);
                printData("It does nothing",action);
            }
            else if (item === "Front House Key" && this.objects[0].locked)
            {
                printData("You put the key into the door and turn",action);
                printData("The key snaps as you turn in",action);
                printData("\"CLICK\"",saying);
                printData("The door seems to be unlocks",thought);

                this.objects[0].locked = false;
                inventory.useItem("Front House Key");
            }
            else
            {
                printData("I'm not using this on that",error);
            }
        break;
        }
        default:{
            printData("I'm not using this on that",error);
        }
    }
    }
}