/**
 * File name: BathroomClass.js
 * Assignment: Final Project CSC 337
 * Purpose: Creates the class for the bathroom location. Here the player can play
 *      the tik tak toe minigame. Contains all the objects located in the room, 
 *      and what happens when the user moves, interacts or looks at these objects.
 */
class bathroom extends tempClass {
    name = "bathroom";
    // all objects in this room
    mirror = {id: ["mirror"], played: false, occupies: [21,22,29,30,37,38]}
    objects = [this.mirror,this.exit];

    image = "../images/Bathroom.png";

    /**
     * Handles cases for when a player moves to a specified location in the 
     * room. 
     * @param {*} location  The location player has clicked on 
     */
    move(location) {
        switch (location) {
            case("exit"): {
                travel("hallway");
            }
        }
    }

    /**
     * Handles cases for when a player tries to look at a specified item
     * in the room
     * @param {*} item      The item the player has clicked on
     */
    look(item) {
        switch(item){
            case(this.mirror.id[0]):{
                if(!this.objects[0].played) {
                    if(confirm("Play minigame?"))
                    {
                        this.updateGame();
                        this.objects[0].played = true;
                        this.playMirrorGame();
                    }
                }
                else
                {
                    printData("A game of tiktaktoe was played on the mirror", thought);
                }
                break;
            }
            default:{
                printData("Looks like an old bathroom",thought);
                if(this.objects[0].played)
                {
                    printData("A game of tiktaktoe was played on the mirror", thought);
                }
                else {
                    printData("Something is odd with that mirror", thought);
                }
                break;
            }
        }
    }

    /**
     * Handles cases for when a player interacts with a specified item in the 
     * room.
     * @param {*} item      the item from the room the player is trying to 
     *                      interact with
     */
    interact(item) {
        switch (item)
        {
            case(this.mirror.id[0]):{
                if(!this.objects[0].played)
                {
                    if(confirm("Play minigame?"))
                    {
                        this.updateGame();
                        this.objects[0].played = true;
                        this.playMirrorGame();
                    }
                }
                else
                {
                    printData("Look like the ghost doesn't want to play anymore", thought);
                }
            }
        }
    }

    /**
     * Updates in the server which game has been played
     */
    updateGame()
    {
        var request = new XMLHttpRequest();
        if (!request) {
            alert("ERROR");
            return false;
        }
        request.onreadystatechange =async() => {
            if (request.readyState === XMLHttpRequest.DONE) {
                console.log("LOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOK");
                if(request.response !== "true"){
                    console.log(request.response);
                    //window.location = "";
                }
            }

        }

        let playGame = "tiktaktoe";
        let playHappy = "true";
        var url = "/play/game/";
        request.open('POST', url, true);
        request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        request.send('playGame='+playGame+"&playHappy="+playHappy);
    }

    /**
     * Opens up the tiktaktoe/mirror minigame
     */
    playMirrorGame(){
        var urlAll = "/tiktaktoe";
        var requestAll = new XMLHttpRequest();
        if (!requestAll) {
            alert("ERROR");
            return false;
        }
        requestAll.onreadystatechange = () => {
            if (requestAll.readyState === XMLHttpRequest.DONE) {
                if (requestAll.status === 200) {
                    saveGameData().then(()=>{window.location.href ="tiktaktoe";});
                } else {
                    alert("ERROR");
                }
            }
        }
        requestAll.open('GET', urlAll, true);
        requestAll.send();
    }
}
