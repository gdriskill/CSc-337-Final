/**
 * File name: CodeRoomClass.js
 * Assignment: Final Project CSC 337
 * Purpose: Creates the class for the code room location. Here the player can play
 *      the cryptography puzzle. Contains all the objects located in the room, 
 *      and what happens when the user moves, interacts or looks at these objects.
 */
class codeRoom extends tempClass {
    name = "codeRoom";

    // objects in this room
    tradePit = {id: ["tradePit"], occupies: [53, 54, 55, 45, 46, 47]}
    badEndingDoor = {id: ["badEndingDoor"], occupies: [18, 19, 26, 27, 34, 35, 42, 43]}
    goodEndingDoor = {id: ["goodEndingDoor"], occupies: [21,22,23,29,30,31,37,38,39]}
    objects = [this.goodEndingDoor,this.badEndingDoor, this.tradePit, this.exit];

    image = "../images/CodeRoom.png";

    /**
     * Handles cases for when a player moves to a specified location in the 
     * room. 
     * @param {*} location  The location player has clicked on 
     */
    move(location) {
        switch (location) {
            case("exit"): {
                travel("hallway");
                break;
            }
            case(this.badEndingDoor.id[0]): {
                if (confirm("Are you sure?\nThis option will end the game.")) {
                    travel("ending");
                }
                break;
            }
            default: {
                printMoveError();
            }
        }
    }

    /**
     * Handles cases for when a player tries to look at a specified item
     * in the room
     * @param {*} item      The item the player has clicked on
     */
    look(item) {
        printData("Looks like an old room",thought);
    }

    /**
     * Handles cases for when a player interacts with a specified item in the 
     * room.
     * @param {*} item      the item from the room the player is trying to 
     *                      interact with
     */
    interact(item) {
        switch (item) {
            case(this.tradePit.id[0]): {
                if (confirm("Open market place?")) {
                    this.goToMarketPlace();
                }
                break;
            }
            case(this.goodEndingDoor.id[0]):
            {
                if(inventory.hasItem("Cryptography Book")) {
                    document.getElementById("inputOutline").style.display = "block";
                    CryCode = true;
                }
                else
                {
                    printData("I can't solve this, I would need the cryptography book",thought);
                }
                break;
            }
            default: {
                printPickUpError();
            }
        }
    }

    /**
     * Sends a player to the market place. This function is ran when the user 
     * click on the trading pit in the room.
     */
    goToMarketPlace()
    {
        var request = new XMLHttpRequest();
        if (!request) {
            alert("ERROR");
            return false;
        }
        request.onreadystatechange =async() => {
            if (request.readyState === XMLHttpRequest.DONE) {
                this.openMarketPlace();
            }

        }

        let playGame = "market";
        let playHappy = "true";
        var url = "/play/game/";
        request.open('POST', url, true);
        request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        request.send('playGame='+playGame+"&playHappy="+playHappy);
    }

    /**
     * Opens up the market place screen
     */
    openMarketPlace(){
        var urlAll = "/market";
        var requestAll = new XMLHttpRequest();
        if (!requestAll) {
            alert("ERROR");
            return false;
        }
        requestAll.onreadystatechange = () => {
            if (requestAll.readyState === XMLHttpRequest.DONE) {
                if (requestAll.status === 200) {
                    saveGameData().then(()=>{window.location.href ="market";});
                } else {
                    alert("ERROR");
                }
            }
        }
        requestAll.open('GET', urlAll, true);
        requestAll.send();
    }
}
